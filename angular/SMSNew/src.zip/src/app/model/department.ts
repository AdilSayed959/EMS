export class Department {
    dno = 0

    dname = ""

}
