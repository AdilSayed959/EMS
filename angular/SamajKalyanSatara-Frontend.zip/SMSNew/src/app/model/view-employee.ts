export class ViewEmployee {
    emp_id:number
    emp_name:string
    father_name:string
    dob:string
    doj:string
    dname:string
    desg_type:string
    address:string
    paddress:string
    photo:string
    mobile:string
    email:string
    salary:number
    emppass:string




}
