export class AppConstants {
    static BASE_URL: string = "http://samajkalyansatara.in:8080/SchoolApp/schoolapp/"
    static USER_ID: string = "user_id"
    static USER_EMAIL: string = "user_email"
    static USER_ROLE: string = "user_role"
}
