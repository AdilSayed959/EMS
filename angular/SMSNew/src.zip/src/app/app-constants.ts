export class AppConstants {
    static BASE_URL: string = "http://192.168.1.109:8080/schoolapp/"
    static USER_ID: string = "user_id"
    static USER_EMAIL: string = "user_email"
    static USER_ROLE: string = "user_role"
}
