import { Employee } from "./employee";

export class Attendance {


    att_id = 0

    date_of_att = ""

    emp: Employee = new Employee()

    intime = ""

    outime = ""

    status = ""
}
