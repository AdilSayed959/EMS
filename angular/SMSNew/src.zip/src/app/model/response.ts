export class Response {
    status = false
    msg = ""
    user_id = 0
}
