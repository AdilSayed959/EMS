export class MarkAttendance {
    emp_id: number
    emp_name: string
    intime: string
    outtime: string
    status: string
    date_of_att:string

}
