export class ViewLeave {
    leave_id:number
    emp_id:number
    description:string
    fdate:string
    tdate:string
    status:string
    leavetype:string
    emp_name:string
    remark:string
    approve:string
    reject:string
    isApprove=false
    isReject=false
    isRemark=false
    mobile:string
}
