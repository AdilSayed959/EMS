export class Designation {
    desg_id = 0

    desg_type = ""
}
