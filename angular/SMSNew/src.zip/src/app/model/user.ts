export class User {
    user_id = 0

    user_password = ""

    user_role = ""

    user_email = ""
}
