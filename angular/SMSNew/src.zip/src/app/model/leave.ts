import { Employee } from "./employee"

export class Leave {
    leave_id = 0

    emp: Employee = new Employee()

    leavetype = ""

    fdate = ""

    tdate = ""

    description = ""

    status = ""

    remark=""
}
